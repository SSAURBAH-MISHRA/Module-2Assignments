package com.capgemini.payment.exception;

public class NoTransactionDoneException extends Exception{

	public NoTransactionDoneException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
